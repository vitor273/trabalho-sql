<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>WebNuvem</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
     <h1>WebNuvem</h1>
    <center><button type="submit">Cadastrar</button><center>

    <div class="card"> 
    <button type="button" class="btn btn-primary">Editar</button>
    <div class="card">
    <button type="button" class="btn btn-primary">Excluir</button>
</div>  
</body>
</html>